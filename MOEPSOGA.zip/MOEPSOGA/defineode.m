function dx=defineode(~,x,u)
dx = zeros(4,1);
dx(1)=0.125*x(2)*x(1)/x(4);                              
dx(2)=-25*x(2)*x(1)/(27*x(4))+2.8*u;
dx(3)=-6*x(2)^2*x(1)/(x(4)^2)+16.75*x(1)*x(2)/x(4);
dx(4)=u;

end