function hv = calculateSingleHV(particleCost, nadirPoint)
    % 计算单个粒子的超体积，假设目标是最小化的
    % 如果有最大化目标，需要相应调整
    hv = prod(nadirPoint - particleCost);
end