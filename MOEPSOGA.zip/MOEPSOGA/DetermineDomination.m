

function x=DetermineDomination(x)

    nx=numel(x);
    
    for i=1:nx
        x(i).IsDominated=false;
    end
    
    for i=1:nx-1
        for j=i+1:nx
            
            if Dominates(x(i),x(j))
               x(j).IsDominated=true;
            end
            
            if Dominates(x(j),x(i))
               x(i).IsDominated=true;
            end
            
        end
    end

end