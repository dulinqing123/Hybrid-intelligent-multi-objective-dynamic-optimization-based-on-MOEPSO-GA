function igd = calculateIGD(paretoFront, rep)
    % paretoFront: 真实Pareto前沿，每一列代表一个点，第一行是第一个目标函数值，第二行是第二个目标函数值
    % repCost: 近似Pareto前沿，每一列代表一个点，第一行是第一个目标函数值，第二行是第二个目标函数值
    repCost=[rep.Cost];
    % 获取真实Pareto前沿的点数
    numPointsPF = size(paretoFront, 2);

    % 初始化最小距离数组
    minDistances = zeros(1, numPointsPF);

    % 遍历真实Pareto前沿的每个点
    for i = 1:numPointsPF
        pointPF = paretoFront(:, i);
        % 计算该点到近似Pareto前沿所有点的距离
        distances = sqrt(sum((pointPF - repCost).^2, 1));
        % 找到最小距离
        minDistances(i) = min(distances);
    end

    % 计算IGD值
    igd = sum(minDistances) / numPointsPF;
end