function pop = updatePopWithAE(pop, AE)
    % pop: 粒子群，包含个体最优解和HV值
    % AE: 存放交叉遗传产生的粒子的集合
    % pop: 更新后的粒子群

    nAE = numel(AE); % AE中的粒子数量
    for i = 1:2:nAE-1
        % 两两分组AE中的粒子
        E1 = AE(i);
        E2 = AE(i+1);
        
        % 计算两个粒子的支配性
        if Dominates(E1, E2)
            selectedE = E1;
        elseif Dominates(E2, E1)
            selectedE = E2;
        else
            % 如果互不支配，选择hv值较大的粒子
            if E1.hv > E2.hv
                selectedE = E1;
            else
                selectedE = E2;
            end
        end
        
        % 随机选择一个pop中的粒子
        idx = randi(numel(pop));
        pop_i = pop(idx);
        
        % 比较pop(i).Best.hv和E.hv，hv值较大的粒子E替换pop(i).Best
        if selectedE.hv > pop_i.Best.hv
            pop(idx).Best.Position = selectedE.Position;
            pop(idx).Best.hv = selectedE.hv;
            pop(idx).Best.Cost = selectedE.Cost;
        end
    end
end