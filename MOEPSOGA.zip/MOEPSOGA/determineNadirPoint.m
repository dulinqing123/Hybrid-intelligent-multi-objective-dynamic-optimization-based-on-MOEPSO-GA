function nadirPoint = determineNadirPoint(rep)
    
c=[rep.Cost];
cmax=max(c,[],2);
nadirPoint=cmax;  
end