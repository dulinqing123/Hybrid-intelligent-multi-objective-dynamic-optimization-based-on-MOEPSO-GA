
function leaderM=SelectleaderM(rep)
% 
%     hv_values = [rep.hv]; % 假设rep中每个粒子都有hv属性
% 
%     % 计算选择概率
%     P=exp(betaM*hv_values);
% %    P = hv_values / sum(hv_values); % 将HV值归一化为概率
%     P = P / sum(P);
%     % 使用轮盘赌选择方法选择粒子
%     selectedIndex = RouletteWheelSelection(P);
% 
%     % 根据选择的索引返回对应的粒子
%     leaderM = rep(selectedIndex);


% 获取粒子总数
    M = numel(rep);

    % 根据HV值降序排序粒子，并获取排序后的索引
    [~, sortedIndices] = sort([rep.hv], 'descend');

    % 计算选择概率P(j)
    P = zeros(M, 1);
    for j = 1:M
        P(j) = (M - j + 1) / (M * (M + 1) / 2);
    end
    
    % 标准化选择概率
    P = P / sum(P);
    
    % 使用轮盘赌选择方法选择粒子
    selectedIndex = RouletteWheelSelection(P);
    
    % 根据选择的索引返回对应的粒子
    leaderM = rep(sortedIndices(selectedIndex));

end