function hvtotal = calculatetotalhv(rep,nadirPoint)
costs=[rep.Cost];
hvtotal = 0;
[~, sortIdx] = sort(costs(1, :));

% 使用排序后的索引重新排列整个矩阵的列
sortedCosts = costs(:, sortIdx);
for i = 2:size(sortedCosts,2)
    hvtotal = hvtotal + abs(sortedCosts(2,i ) -sortedCosts( 2,i-1) ) * abs(nadirPoint(1) - sortedCosts( 1,i));
end
hvtotal = hvtotal + abs(sortedCosts(2,1 ) -nadirPoint(2) ) * abs(nadirPoint(1) - sortedCosts( 1,1));
end

