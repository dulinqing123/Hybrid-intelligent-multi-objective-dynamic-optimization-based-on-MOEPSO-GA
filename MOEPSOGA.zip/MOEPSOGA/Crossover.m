function E = Crossover(pc,rep,betaF)


    leaderF=SelectleaderF(rep,betaF);
    leaderM=SelectleaderM(rep);

    % 获取位置的维数
    nVar = length(leaderM.Position);

    % 进行交叉操作
    for j = 1:nVar
        rc = rand; % 生成一个随机数
        if rc > pc
            E(j) = leaderM.Position(j); % 选择 leaderM 的位置
        else
            E(j) = leaderF.Position(j); % 选择 leaderF 的位置
        end
    end
end