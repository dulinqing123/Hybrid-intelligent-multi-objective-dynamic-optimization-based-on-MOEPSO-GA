clc;
clear;
close all;
H = cputime;
global x0 T N R
x0=[0.1 14 0 5];
T=40;
N=10;
R=400;
%% Problem Definition
CostFunction=@(u) costfunction(u);      % Cost Function
nVar=10;             % Number of Decision Variables
VarSize=[1 nVar];   % Size of Decision Variables Matrix
VarMin=0;          % Lower Bound of Variables
VarMax=2;          % Upper Bound of Variables
VMin=-2;
VMax=2; 
%% MOPSO Parameters
MaxIt=50;           % Maximum Number of Iterations
nPop=100;            % Population Size
nRep=100;            % Repository Size
w=0.75;              % Inertia Weight
wdamp=0.99;         % Intertia Weight Damping Rate
c1=0.4;               % Personal Learning Coefficient
c2=0.4;               % Global Learning Coefficient
nGrid=30;            % Number of Grids per Dimension
alpha=0.1;          % Inflation Rate
beta=2;             % Leader Selection Pressure
betaF=2;
pc=0.5;
gamma=2;            % Deletion Selection Pressure
mu=0.1;             % Mutation Rate
%% Initialization
empty_particle.Position=[];
empty_particle.Velocity=[];
empty_particle.Cost=[];
empty_particle.Best.Position=[];
empty_particle.Best.Cost=[];
empty_particle.IsDominated=[];
empty_particle.GridIndex=[];
empty_particle.GridSubIndex=[];
empty_particle.hv=[];
pop=repmat(empty_particle,nPop,1);
empty_E.Position=[];
empty_E.Velocity=[];
empty_E.Cost=[];
empty_E.Best.Position=[];
empty_E.Best.Cost=[];
empty_E.Best.X=[];
empty_E.IsDominated=[];
empty_E.GridIndex=[];
empty_E.GridSubIndex=[];
empty_E.hv=[];
E=repmat(empty_E,1);
AE=[];
for i=1:nPop
    pop(i).Position=unifrnd(VarMin,VarMax,VarSize);
    pop(i).Velocity=unifrnd(VMin,VMax,VarSize);
    pop(i).Cost=CostFunction(pop(i).Position);
    pop(i).Best.Position=pop(i).Position;
    pop(i).Best.Cost=pop(i).Cost;  
end
pop=DetermineDomination(pop);
rep=pop(~[pop.IsDominated]);
nadirPoint =[-12.5;-0.5];
pop = calculateHV(pop, nadirPoint);
rep = calculateHV(rep, nadirPoint);
  for i=1:nPop  
  pop(i).Best.hv=pop(i).hv; 
  end
Grid=CreateGrid(rep,nGrid,alpha);
for i=1:numel(rep)
    rep(i)=FindGridIndex(rep(i),Grid);
end
%% Main Loop  
 for it=1:MaxIt
        GB=SelectGB(rep,beta);
    for i=1:nPop
        E.Position = Crossover(pc,rep,betaF);
        E.Cost=CostFunction(E.Position);
        pm=(1-(it-1)/(MaxIt-1))^(1/mu);
        if rand<pm
            NewSol.Position=Mutate(E.Position,pm,VarMin,VarMax);
            NewSol.Cost=CostFunction(NewSol.Position);
            if Dominates(NewSol,E)
                E.Position=NewSol.Position;
                E.Cost=NewSol.Cost;
            elseif Dominates(E,NewSol)
            else
                if rand<0.5
                    E.Position=NewSol.Position;
                    E.Cost=NewSol.Cost;
                end
            end
        end
        E = calculateHV(E, nadirPoint);
        if E.hv > pop(i).Best.hv
            if E.hv > GB.hv
                pop(i).Velocity = w*pop(i).Velocity ...
                    +c1*rand(VarSize).*(E.Position-pop(i).Position);
            else
                pop(i).Velocity = w*pop(i).Velocity ...
                   +c1*rand(VarSize).*(E.Position-pop(i).Position) ...
                   +c2*rand(VarSize).*(GB.Position-pop(i).Position);
            end
            if numel(AE) < nPop
                AE=[AE
                       E]; 
            else
                indices = randperm(numel(AE), 2);
                E1 = AE(indices(1));
                E2 = AE(indices(2));
                if E1.hv < E2.hv
                     AE(indices(1)) = E;
                else
                     AE(indices(2)) = E;
                end
            end
        else
            if pop(i).Best.hv > GB.hv
                pop(i).Velocity = w*pop(i).Velocity ...
                    +c1*rand(VarSize).*(pop(i).Best.Position-pop(i).Position);
            else
                pop(i).Velocity = w*pop(i).Velocity ...
                   +c1*rand(VarSize).*(pop(i).Best.Position-pop(i).Position) ...
                   +c2*rand(VarSize).*(GB.Position-pop(i).Position);
            end
        end
        pop(i).Position = pop(i).Position + pop(i).Velocity;
        pop(i).Position = max(pop(i).Position, VarMin);
        pop(i).Position = min(pop(i).Position, VarMax);
        pop(i).Cost=CostFunction(pop(i).Position);
    end
    rep=[rep
             pop]; 
    rep=[rep
             AE];
    rep=DetermineDomination(rep);
    rep=rep(~[rep.IsDominated]);
    nadirPoint =[-12.5;-0.5];
    pop = calculateAllHV(pop, nadirPoint);
    rep = calculateAllHV(rep, nadirPoint);
    for i=1:nPop
        if Dominates(pop(i),pop(i).Best)
            pop(i).Best.Position=pop(i).Position;
            pop(i).Best.Cost=pop(i).Cost;
            pop(i).Best.hv=pop(i).hv;
        elseif Dominates(pop(i).Best,pop(i))
        else
            if rand<0.5
                pop(i).Best.Position=pop(i).Position;
                pop(i).Best.Cost=pop(i).Cost;
                pop(i).Best.hv=pop(i).hv;
            end
        end 
    end
    pop = updatePopWithAE(pop, AE);
    Grid=CreateGrid(rep,nGrid,alpha);
    for i=1:numel(rep)
        rep(i)=FindGridIndex(rep(i),Grid);
    end
    if numel(rep)>nRep 
        Extra=numel(rep)-nRep;
        for e=1:Extra
            rep=DeleteOneRepMemebr(rep,gamma);
        end
    end
     figure(1);
     PlotCosts(pop,rep);
     pause(0.01);
     disp(['Iteration ' num2str(it) ': Number of Rep Members = ' num2str(numel(rep))]);
    w=w*wdamp;
    EPC = [rep.Cost];
    range2=max(EPC(2, :))-min(EPC(2, :));
    range1=max(EPC(1, :))-min(EPC(1, :));
end
 Time=cputime-H;
 nadirPoint =[-12.5;-0.5];
 hvtotal=calculatetotalhv(rep,nadirPoint);
 load('paretoFront.mat');
 igd = calculateIGD(paretoFront, rep);
 sp = SP(rep);


