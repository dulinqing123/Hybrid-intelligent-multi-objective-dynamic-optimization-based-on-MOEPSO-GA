function z=costfunction(u)
global T N x0 lb ub R Y xbest xxi y0 costfunctiony0
    n=numel(u);
        y0=x0;
        options = odeset('RelTol', 1e-1, 'AbsTol', 1e-4, 'Refine', R);
        for i = 1:N
            [t,x]=ode45(@(t,x)defineodeu(t,x,u(:,i)),[(i-1)*T/(N),i*T/(N)],y0,options);
            y0 = x(end, :);
        end
f1 = -x(end,3)/(2.8*x(end,4)-x(end,2));  
f2 =-x(end,3)/2400;
z=[f1 
     f2];
end