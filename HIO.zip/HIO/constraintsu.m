
function [c, ceq] = constraintsu(u)
    global T N x0 EP2
    y0 = x0;
    x = zeros(4, N+1);
    for i = 1:N
        [~,x_temp] = ode45(@(t,x) defineodeu(t,x,u(i)), [(i-1)*T/N, i*T/N], y0);
        x(:,i+1) = x_temp(end, :); 
        y0 = x_temp(end, :);
    end
    c = -x(3,end)/2400 + EP2; % 这是一个不等式约束
    ceq = []; % 没有等式约束
end



