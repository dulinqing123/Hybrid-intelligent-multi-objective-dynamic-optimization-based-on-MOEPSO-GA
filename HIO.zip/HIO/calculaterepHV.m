function rep = calculaterepHV(rep, nadirPoint)
    nrep = numel(rep); % 粒子数量
%      pop.hv= zeros(nPop, 1); % 初始化超体积值数组

    for i = 1:nrep
        % 计算第i个粒子的超体积
        rep(i).hv = calculateSingleHV(rep(i).Cost, nadirPoint);
    end
end