H = cputime;
psohv=[];
global x0 T N R u0 lb ub EP2
x0=[0.1 14 0 5];
T=40;
N=10;
R=400;
HVchange=[];
%% Problem Definition
CostFunction=@(u) costfunction(u);      % Cost Function
nVar=10;             % Number of Decision Variables
VarSize=[1 nVar];   % Size of Decision Variables Matrix
VarMin=0;          % Lower Bound of Variables
VarMax=2;          % Upper Bound of Variables
VMin=-2;
VMax=2;
%% MOPSO Parameters
MaxIt=25;           % Maximum Number of Iterations
nPop=100;            % Population Size
nRep=100;            % Repository Size
w=0.5;              % Inertia Weight
wdamp=0.99;         % Intertia Weight Damping Rate
c1=0.4;               % Personal Learning Coefficient
c2=0.4;               % Global Learning Coefficient
nGrid=30;            % Number of Grids per Dimension
alpha=0.1;          % Inflation Rate
beta=2;             % Leader Selection Pressure
betaF=2;
betaM=2;
pc=0.5;
gamma=2;            % Deletion Selection Pressure
mu=0.1;             % Mutation Rate
%% Initialization
empty_particle.Position=[];
empty_particle.Velocity=[];
empty_particle.Cost=[];
empty_particle.Best.Position=[];
empty_particle.Best.Cost=[];
empty_particle.IsDominated=[];
empty_particle.GridIndex=[];
empty_particle.GridSubIndex=[];
empty_particle.hv=[];
pop=repmat(empty_particle,nPop,1);
empty_E.Position=[];
empty_E.Velocity=[];
empty_E.Cost=[];
empty_E.Best.Position=[];
empty_E.Best.Cost=[];
empty_E.Best.X=[];
empty_E.IsDominated=[];
empty_E.GridIndex=[];
empty_E.GridSubIndex=[];
empty_E.hv=[];
E=repmat(empty_E,1);
AE=[];
for i=1:nPop
    pop(i).Position=unifrnd(VarMin,VarMax,VarSize);
    pop(i).Velocity=unifrnd(VMin,VMax,VarSize);
    pop(i).Cost=CostFunction(pop(i).Position);
    pop(i).Best.Position=pop(i).Position;
    pop(i).Best.Cost=pop(i).Cost;
end
pop=DetermineDomination(pop);
rep=pop(~[pop.IsDominated]);
nadirPoint = determineNadirPoint(rep);
pop = calculateHV(pop, nadirPoint);
rep = calculateHV(rep, nadirPoint);
for i=1:nPop
    pop(i).Best.hv=pop(i).hv;
end
Grid=CreateGrid(rep,nGrid,alpha);
for i=1:numel(rep)
    rep(i)=FindGridIndex(rep(i),Grid);
end
psohvtotal=0;
lastpsohvtotal=100;
%%  Main Loop
it=0;
 while (it<50 && abs(lastpsohvtotal-psohvtotal)>0.004 )
lastpsohvtotal=psohvtotal;
it=it+1;
    for i=1:nPop
        GB=SelectGB(rep,beta);
        E.Position = Crossover(pc,rep,betaF,betaM);
        E.Cost=CostFunction(E.Position);
        pm=(1-(it-1)/(MaxIt-1))^(1/mu);
        if rand<pm
            NewSol.Position=Mutate(E.Position,pm,VarMin,VarMax);
            NewSol.Cost=CostFunction(NewSol.Position);
            if Dominates(NewSol,E)
                E.Position=NewSol.Position;
                E.Cost=NewSol.Cost;

            elseif Dominates(E,NewSol)

            else
                if rand<0.5
                    E.Position=NewSol.Position;
                    E.Cost=NewSol.Cost;
                end
            end
        end
        E = calculateHV(E, nadirPoint);
        if E.hv > pop(i).Best.hv
            if E.hv > GB.hv
                pop(i).Velocity = w*pop(i).Velocity ...
                    +c1*rand(VarSize).*(E.Position-pop(i).Position);
            else
                pop(i).Velocity = w*pop(i).Velocity ...
                    +c1*rand(VarSize).*(E.Position-pop(i).Position) ...
                    +c2*rand(VarSize).*(GB.Position-pop(i).Position);
            end
            if numel(AE) < nPop
                AE=[AE
                    E];
            else
                indices = randperm(numel(AE), 2);
                E1 = AE(indices(1));
                E2 = AE(indices(2));
                if E1.hv < E2.hv
                    AE(indices(1)) = E;
                else
                    AE(indices(2)) = E;
                end
            end
        else
            if pop(i).Best.hv > GB.hv
                pop(i).Velocity = w*pop(i).Velocity ...
                    +c1*rand(VarSize).*(pop(i).Best.Position-pop(i).Position);
            else
                pop(i).Velocity = w*pop(i).Velocity ...
                    +c1*rand(VarSize).*(pop(i).Best.Position-pop(i).Position) ...
                    +c2*rand(VarSize).*(GB.Position-pop(i).Position);
            end
        end
        pop(i).Position = pop(i).Position + pop(i).Velocity;
        pop(i).Position = max(pop(i).Position, VarMin);
        pop(i).Position = min(pop(i).Position, VarMax);
        pop(i).Cost=CostFunction(pop(i).Position);
    end
    rep=[rep
        pop]; 
    rep=[rep
        AE]; 
    rep=DetermineDomination(rep);
    rep=rep(~[rep.IsDominated]);
    nadirPoint = determineNadirPoint(rep);
    pop = calculateAllHV(pop, nadirPoint);
    rep = calculateAllHV(rep, nadirPoint);
    for i=1:nPop
        if Dominates(pop(i),pop(i).Best)
            pop(i).Best.Position=pop(i).Position;
            pop(i).Best.Cost=pop(i).Cost;
            pop(i).Best.hv=pop(i).hv;
        elseif Dominates(pop(i).Best,pop(i))
        else
            if rand<0.5
                pop(i).Best.Position=pop(i).Position;
                pop(i).Best.Cost=pop(i).Cost;
                pop(i).Best.hv=pop(i).hv;
            end
        end
    end
    pop = updatePopWithAE(pop, AE);
    Grid=CreateGrid(rep,nGrid,alpha);
    for i=1:numel(rep)
        rep(i)=FindGridIndex(rep(i),Grid);
    end
    if numel(rep)>nRep

        Extra=numel(rep)-nRep;
        for e=1:Extra
            rep=DeleteOneRepMemebr(rep,gamma);
        end
    end
    nadirPointp = [-12.5;-0.5];
    psohvtotal=calculatepsototalhv(rep,nadirPointp);
    psohv=[psohv psohvtotal];
    figure(1);
    PlotCosts(pop,rep);
    pause(0.01);
    disp(['Iteration ' num2str(it) ': Number of Rep Members = ' num2str(numel(rep))]);
    w=w*wdamp;

end
Time1=cputime-H;

utotla=[];
u0 = 1;
lb = 0;
ub = 2;
CE=[];
FMIN=[];
MM = [];
empty_pareto.E1=[];
empty_pareto.E2=[];
empty_pareto.Position=[];
pareto=repmat(empty_pareto,numel(rep),1);
costsMatrix = [rep.Cost];
for i=1:numel(rep)
    pareto(i).E1=costsMatrix(1,i);
    pareto(i).E2=-costsMatrix(2,i);
    pareto(i).Position=rep(i).Position;
end
E2_values = [pareto.E2]; 
[Cmax, maxIndex] = max(E2_values);
[Cmin, minIndex] = min(E2_values);
u = pareto(maxIndex).Position;
utotla=[utotla
    u];
multi_FBR=[];
EP2=Cmax;
while EP2>Cmin
    CE=[CE EP2];
    [U, fmin, flag_inf,output,lamda] = seqnlpu(u);
    lamda.ineqnonlin;
    multi_FBR=lamda.ineqnonlin(1,1);
    EP2=EP2-0.024/(sqrt(1+multi_FBR^2));
    E2_values = [pareto.E2];
    [~, idx] = min(abs(E2_values - EP2));
    u = pareto(idx).Position;
    utotla=[utotla
        u];
    FMIN=[FMIN fmin];
    MM = [MM multi_FBR];
end
EP2=Cmin;
CE=[CE EP2];
u = pareto(minIndex).Position;
utotla=[utotla
    u];
[U, fmin, flag_inf,output,lamda] = seqnlpu(u);
lamda.ineqnonlin;
multi_FBR=lamda.ineqnonlin(1,1);

FMIN=[FMIN fmin];
MM = [MM multi_FBR];
CE_negative = -CE;
figure(1);
PlotCosts(pop, rep);
pause(0.01);
hold on; 
plot(FMIN,CE_negative,  'bo');
grid on;
hold off;
Time2=cputime-H;
paretoFront=[];
for i=1:numel(FMIN)
    paretoFronti = [FMIN(i)
        CE_negative(i)];
    paretoFront=[paretoFront paretoFronti];
end
Time=cputime-H;

 nadirPointp = [-12.5;-0.5];
 hvtotal=calculatetotalhv(paretoFront,nadirPointp);
 K=numel(FMIN);
 sp=SP(paretoFront,K);
