

function sp = SP(REP,K)

% REP = [rep.Cost];
% K = numel(REP); % 获取解的数量和目标函数的数量
% % res = inf(1, K); % 初始化res数组为无穷大
res=[];
for i = 1:K
    d = 999; % 使用inf作为初始值
    for j = 1:K
       if i ~= j % 使用~=而不是==来避免与自己比较
%            d = min(d, sqrt((f1(i) - f1(j))^2 + (f2(i ) - f2(2 ))^2)); % 计算欧几里得距离
      d=min(d,abs(REP(1, i)-REP(1, j))+abs(-REP(2,i )+REP(2,j)));
    end
    end
%     res(i) = d;
    res=[res d];
end

equ = mean(res); % 计算平均距离
sum = 0;
for i = 1:K
    sum = sum + (equ - res(i))^2; % 累加平方差
end
sp = sqrt(sum / (K - 1)); % 计算SP值% sp = sqrt(sum / (K - 1)); % 计算SP值