
function pareto_optimal_solutions = findNonDominatedSolutions(data)
    % 输入：
    % data - 2 x n 的矩阵，每一列是一个解，第一行是第一个目标函数的值，第二行是第二个目标函数的值
    % 输出：
    % pareto_optimal_solutions - 筛选后的非支配解

    % 获取数据的大小
    [num_objectives, num_solutions] = size(data);
    
    % 初始化一个逻辑数组，用于标记每个解是否是非支配的
    is_pareto_optimal = true(1, num_solutions);
    
    % 遍历每个解
    for i = 1:num_solutions
        % 如果当前解已经被标记为非非支配解，则跳过
        if ~is_pareto_optimal(i)
            continue;
        end
        
        % 比较当前解与其他解
        for j = 1:num_solutions
            % 跳过自身比较
            if i == j
                continue;
            end
            
            % 如果解 j 在所有目标上都不比解 i 差，并且在至少一个目标上优于解 i
            if all(data(:, j) <= data(:, i)) && any(data(:, j) < data(:, i))
                % 标记解 i 为非支配解
                is_pareto_optimal(i) = false;
                break;
            end
        end
    end
    
    % 提取非支配解
    pareto_optimal_solutions = data(:, is_pareto_optimal);
end